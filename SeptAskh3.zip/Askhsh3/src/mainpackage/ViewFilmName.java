package mainpackage;

import askhsh1.Films;
import dao.FilmDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewFilmName")
public class ViewFilmName extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<title>View Film</title>");
		
		request.getRequestDispatcher("viewfilmname.jsp").include(request, response);
		
		out.println("<h1 style=\"color:orange;\">View Film Names</h1>");
		List<Films> list = FilmDao.getAllRecords();
		out.print("<table style=\"color:white;\" >");
		for(Films f:list){
			out.println("<tr><td>"+f.getFilmId()+"</td><td>"+f.getFilmTitle()+"</td><td>"+f.getFilmCategory()+"</td><td>"+f.getFilmDescription()+"</td>");
			
			out.println("</tr>");
		}
		out.println("</table>");
		out.close();
	}

}

