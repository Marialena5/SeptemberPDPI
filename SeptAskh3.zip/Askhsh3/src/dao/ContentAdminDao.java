package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class ContentAdminDao {
	
	
public static boolean validate(String username, String hashed, String salt){
	
	boolean status = false;
	try{
		InitialContext ctx = new InitialContext();
		DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
		Connection con = datasource.getConnection();
		PreparedStatement ps = con.prepareStatement("select * from contentadmin where contentadmin_name =? and idca_hashed_pass=? and idca_salt=?");
		ps.setString(1,username);
		ps.setString(2,hashed);
		ps.setString(3,salt);
		ResultSet rs = ps.executeQuery();
		status = rs.next();
		con.close();
	}catch(Exception ex){System.out.println(ex);}
	return status;
}

}

