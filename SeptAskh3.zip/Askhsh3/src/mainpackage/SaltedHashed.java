package mainpackage;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SaltedHashed {
	 
//	public static String getMd5(String input) 
//    { 
//        try { 
//  
//            // Static getInstance method is called with hashing MD5 
//            MessageDigest md = MessageDigest.getInstance("MD5"); 
//  
//            // digest() method is called to calculate message digest 
//            //  of an input digest() return array of byte 
//            byte[] messageDigest = md.digest(input.getBytes()); 
//  
//            // Convert byte array into signum representation 
//            BigInteger no = new BigInteger(1, messageDigest); 
//  
//            // Convert message digest into hex value 
//            String hashtext = no.toString(16); 
//            while (hashtext.length() < 32) { 
//                hashtext = "0" + hashtext; 
//            } 
//            return hashtext; 
//        }  
//  
//        // For specifying wrong message digest algorithms 
//        catch (NoSuchAlgorithmException e) { 
//            throw new RuntimeException(e); 
//        } 
//    } 
	
	public static String getHashMD5(String unhashed) {
	        return getHashMD5(unhashed, "");
	    }

	    /**
	     * Computes the hash of the given string salted. Return the hash uppercase.
	     * @param unhashed the string to hash
	     * @param salt the salt to use
	     * @return the hash of the given string salted and uppercase.
	     * @throws NoSuchAlgorithmException
	     */
	    public static String getHashMD5(String unhashed, String salt) {
	        // Hash the password.
	        final String toHash = salt + unhashed + salt;
	        MessageDigest messageDigest = null;
	        try {
	            messageDigest = MessageDigest.getInstance("MD5");
	        } catch (NoSuchAlgorithmException ex) {
	            return "00000000000000000000000000000000";
	        }
	        messageDigest.update(toHash.getBytes(), 0, toHash.length());
	        String hashed = new BigInteger(1, messageDigest.digest()).toString(16);
	        if (hashed.length() < 32) {
	            hashed = "0" + hashed;
	        }
	        return hashed.toUpperCase();
	    }

}
