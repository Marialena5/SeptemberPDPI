package askhsh1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ContentAdmins extends Films{
	
	public ContentAdmins (String filmId, String filmTitle, String filmCategory, String filmDescription) 
	{
		super(filmId, filmTitle, filmCategory, filmDescription);
	}

	File filmsFile = new File("films.txt");   // Our File with films 
	File tempFile = new File("myTempFile.txt");// Temp file
	
	/**
	 * This method reads the file "films.txt" to look for the inserted filmId and filmTitle. 
	 * If filmId is found, it prints out that the filmId already exists,
	 * If filmTitle is found, it prints out that the Film already exists,
	 * If filmId and filmTitle are found, it prints out that the Film already exists and in any other case 
	 * it writes the inserted filmId, filmTitle, filmCategory and filmDescription in a new line at the end of 
	 * our file.
	 * @param filmId
	 * @param filmTitle
	 * @param filmCategory
	 * @param filmDescription
	 */
	public void insertFilms(String filmId, String filmTitle, String filmCategory, String filmDescription) {
		
		try { 
	    	boolean film = true;
		    try {
		    	
	        Scanner reader = new Scanner(filmsFile); 
	        
	        while (reader.hasNextLine()) {
		          String data = reader.nextLine();
		          String[] arrOfStr = data.split(","); 
		          
		          String id = arrOfStr[0]; // TODO comment out?
		          String title = arrOfStr[1];
		          
		          if (id.equals(filmId) && title.equals(filmTitle) || title.equals(filmTitle)) {
	        		  film = false;
	        		  System.out.println("Film already exist in our database!");
	        		  break;
	        		  } else if(id.equals(filmId)) {
	        			  film = false;
		        		  System.out.println("ID already exist in our database!");
		        		  break;
	        		  }else
	        			  System.out.println("OK");
	        }
	        reader.close();
		    } catch (Exception ex) { // TODO apply the right exception
		    	
		    }
		    if (film == true) {
			    
		        FileWriter myWriter = new FileWriter("films.txt", true);
		       
		        myWriter.append(filmId + "," + filmTitle + "," + filmCategory + "," + filmDescription + "\r\n");
		        myWriter.close();
		        System.out.println("Successfully wrote to the file.");
		        System.out.println("ID: " + getFilmId());
		        System.out.println("Title: " + getFilmTitle());
	        	System.out.println("Category: " + getFilmCategory());
	        	System.out.println("Description: " + getFilmDescription());
		  	        
	  	        }
		    
	      } catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }    
	}

	/**
	 * This method reads the file "films.txt" in order to find the line that includes the inserted filmId
	 * and at the same time writes the content of this line in the temporary file "myTempFile.txt".
	 * When the line including the filmId is found, its content will not be written at the temporary file.
	 * In the end, "films.txt" will be deleted and the temporary file will be renamed to "films.txt"
	 * @param filmId
	 * @throws IOException
	 */
	public void deleteFilms(String filmId) throws IOException {
		
		boolean film = false;
		
		try {
			
		BufferedReader reader = new BufferedReader(new FileReader(filmsFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String currentLine;
		
		while ((currentLine = reader.readLine()) != null) {
		      String[] arrOfStr = currentLine.split(","); 
		      
		      String id = arrOfStr[0];
		      
			  if (id.equals(filmId)) {
				  film = true;
				  System.out.println("Delete OK");
				  continue;
				  
			  }
			  writer.write(currentLine + "\r\n");
	  
		}
			if(film == false) {
					
				System.out.println("Wrong!");		
			}
		
		reader.close();
		writer.close();	
		filmsFile.delete();
		tempFile.renameTo(filmsFile);
		
		} catch (Exception ex) { // TODO apply the right exception
			
		} 
	}
	
}

