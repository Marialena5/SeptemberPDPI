package mainpackage;

import askhsh1.Provoles;
import dao.ProvolesDao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ContentAdminProvoles")
public class ContentAdminProvoles extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		request.getRequestDispatcher("insertprovoles.jsp").include(request, response);
		
		String movies_idmovies = request.getParameter("movies_idmovies");
		String provoles_start_date = request.getParameter("provoles_start_date");
		String provoles_end_date = request.getParameter("provoles_end_date");
		String cinemas_idcinemas = request.getParameter("cinemas_idcinemas");
		String contentadmin_idcontentadmin = request.getParameter("contentadmin_idcontentadmin");
			
		Provoles p = new Provoles();
		p.setProvoliFilm(movies_idmovies);
		p.setProvoliStartDate(provoles_start_date);
		p.setProvoliEndDate(provoles_end_date);
		p.setProvoliCinema(cinemas_idcinemas);
		p.setProvoliID(contentadmin_idcontentadmin);
		
		if(movies_idmovies == "" || provoles_start_date == "" || provoles_end_date == "" || cinemas_idcinemas == ""|| contentadmin_idcontentadmin == "") {
			
			out.print("<h3 style= \"color:white;\">Unable to add provoli!</h3>");
			
		}else {
			
			int status = ProvolesDao.save(p);
			
			if(status>0){
				
				out.print("<h3 style= \"color:white;\">Provoli added successfully</h3>");
				
			}else{
				out.print("<h3 style= \"color:white;\">Unable to add provoli!</h3>");
			}
					
		}
		
		out.close();
	}

}
