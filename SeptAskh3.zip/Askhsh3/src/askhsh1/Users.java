package askhsh1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Users extends Provoles{

	private String name, username, password, idCa, idCaHash, idCaSalt;
	
	public Users(String name, String username, String password) {
		this.name = name;
		this.username = username;
		this.password = password;
	}
	
	public Users(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public Users(String username) {
		this.username = username;
	}
	
	public Users() {
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getIdCa() {
		return idCa;
	}

	public void setIdCa(String idCa) {
		this.idCa = idCa;
	}
	
	public String getIdCaHash() {
		return idCaHash;
	}

	public void setIdCaHash(String idCaHash) {
		this.idCaHash = idCaHash;
	}
	
	public String getIdCaSalt() {
		return idCaSalt;
	}

	public void setIdCaSalt(String idCaSalt) {
		this.idCaSalt = idCaSalt;
	}
	/**
	 * This method searches each line of the file "users.txt" until it finds 
	 * the inserted username, which is unique. 
	 * @param inpUsername
	 * @param inpPass
	 */
	
	public void login(String inpUsername, String inpPass) {
	   
		try {
	 
	        Scanner myReader = new Scanner(new File("users.txt")); 
	        while (myReader.hasNextLine()) {
	          String data = myReader.nextLine();
	          String[] arrOfStr = data.split(","); 
	          
	          String name_ = arrOfStr[0];
	          String user_name = arrOfStr[1];
	          String pass_word = arrOfStr[2];
	          
	          if (user_name.equals(inpUsername)) {
	        	System.out.println("Name: " + name_ + " Password: " + pass_word);
	        	  
	          }else {
	        	
	        	  System.out.println("Incorrect username and password!");	 
	          }
	        }      	
	        myReader.close();
	        
	      } catch (FileNotFoundException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }
	}
	
	/**
	 * This method resets the value of the variables username and password 
	 */
	
	public void logout() {
		username = " ";
		password = " ";
		System.out.println("You have succesfully logged out");
	}
	
}
