package mainpackage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import askhsh1.Provoles;
import dao.ClientDao;
import java.io.PrintWriter;
import java.util.List;


/**
 * Servlet implementation class ClientSearchAvailableFilm
 */
@WebServlet("/ClientSearchAvailableFilm")
public class ClientSearchAvailableFilm extends HttpServlet {       

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String provoles_movies_idmovies = request.getParameter("provoles_movies_idmovies");		

		request.getRequestDispatcher("availableFilms.jsp").include(request, response);
		
		out.println("<h1>Films Programm by "+provoles_movies_idmovies.toUpperCase()+"</h1>");
		List<Provoles> list = ClientDao.getAvailableFilms(provoles_movies_idmovies);
		
		if(list.isEmpty()) {
			out.print("<table style=\"color:white;\" >");
			out.println("<tr><td>Sorry but the selected film is not available!</td></tr>");
			
		}else {
		out.print("<table style=\"color:white;\" >");
		out.println("<tr><th>Id Films</th><th>Is it Available?</th></tr>");
		
		for(Provoles b:list){
			out.println("<tr><td>"+b.getProvoliID()+"</td><td>"+ b.isProvoliIsAvailable() +"</td></tr>");
		}
		out.println("</table>");
		}
		out.close();
	}

}
