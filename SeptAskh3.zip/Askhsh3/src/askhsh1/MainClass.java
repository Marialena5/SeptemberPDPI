package askhsh1;

import java.io.IOException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	    
	    Scanner scanner = new Scanner (System.in);
	    
	    System.out.println("Which category do you belong to?");

	    System.out.println("1. Customer");
		System.out.println("2. Content Admin");
		System.out.println("3. Application Admin");
		String firstchoice = scanner.nextLine();
		
		
		switch(firstchoice) {
		case "1":
			System.out.println("1. Show Available Films");
			System.out.println("2. Make Reservation");
			System.out.println("3. View Reservation");
			
			String choice = scanner.nextLine();
			
			Customers customer = new Customers(choice);
			Provoles provoles = new Provoles(choice, choice, choice, choice, choice, Integer.parseInt(choice), Boolean.parseBoolean(choice));
			
			switch(choice) {
			
			case "1":
				
				customer.showAvailableFilms();
				break;
			case "2":
				
				System.out.println("Give me your username: ");
				customer.setUsername(scanner.nextLine());
				System.out.println("Give me the Title: ");
				provoles.setProvoliFilm(scanner.nextLine());
				System.out.println("Give me the number of seats: ");
				provoles.setProvoliNumberOfReservations(scanner.nextInt());
				customer.makeReservation(customer.getUsername(), provoles.getProvoliFilm(), provoles.getProvoliNumberOfReservations());
				break;
			case "3":
				
				System.out.println("Give me your username: ");
				customer.setUsername(scanner.nextLine());
				customer.viewReservation(customer.getUsername());
				break;
			
			}
			
			break;
		case "2": 
			
			System.out.println("1. Insert Film");
			System.out.println("2. Delete Film");
			
			String cachoice = scanner.nextLine();
			
			ContentAdmins contentadmin = new ContentAdmins(cachoice, cachoice, cachoice, cachoice);
			
			switch(cachoice) {
			
			case "1":
				
				System.out.println("Give me the ID: ");
				contentadmin.setFilmId(scanner.nextLine());
				System.out.println("Give me the Title: ");
				contentadmin.setFilmTitle(scanner.nextLine());
				System.out.println("Give me the Category: ");
				contentadmin.setFilmCategory(scanner.nextLine());
				System.out.println("Give me the Description: ");
				contentadmin.setFilmDescription(scanner.nextLine());

				contentadmin.insertFilms(contentadmin.getFilmId(), contentadmin.getFilmTitle(), contentadmin.getFilmCategory(), contentadmin.getFilmDescription());
				scanner.close();
				break;
			case "2":
				
				System.out.println("Give me the ID: ");
				contentadmin.setFilmId(scanner.nextLine());

				contentadmin.deleteFilms(contentadmin.getFilmId());
				scanner.close();
				break;
			}
			
			scanner.close();
			break;
			
		case "3":
			
			System.out.println("1. View All Users");
			System.out.println("2. Create User");
			System.out.println("3. Search User");
			System.out.println("4. Update User");
			System.out.println("5. Delete User");
			System.out.println("6. Register Admin");
			
			String achoice = scanner.nextLine();
			
			Admins admin = new Admins(achoice, achoice, achoice);
			
			switch(achoice) {
			
			case "1":
				
				admin.viewAllUsers();
				scanner.close();
				break;
			case "2":
				
				System.out.println("Give me your Name: ");
				admin.setName(scanner.nextLine());
				System.out.println("Give me your Username: ");
				admin.setUsername(scanner.nextLine());
				System.out.println("Give me your Password: ");
				admin.setPassword(scanner.nextLine());

				admin.createUser(admin.getName(), admin.getUsername(), admin.getPassword());
				scanner.close();
				break;
			case "3":
				
				System.out.println("Give me your Username: ");
				admin.setUsername(scanner.nextLine());

				admin.searchUser(admin.getUsername());
				scanner.close();
				break;
			case "4":
				
				System.out.println("Give me your Name: ");
				admin.setName(scanner.nextLine());
				System.out.println("Give me your Username: ");
				admin.setUsername(scanner.nextLine());
				System.out.println("Give me your Password: ");
				admin.setPassword(scanner.nextLine());

				admin.updateUser(admin.getName(), admin.getUsername(), admin.getPassword());
				scanner.close();
				break;
			case "5":
				
				System.out.println("Give me your Username: ");
				admin.setUsername(scanner.nextLine());

				admin.deleteUser(admin.getUsername());
				scanner.close();
				break;
			case "6":
				
				System.out.println("Give me your Name: ");
				admin.setName(scanner.nextLine());
				System.out.println("Give me your Username: ");
				admin.setUsername(scanner.nextLine());
				System.out.println("Give me your Password: ");
				admin.setPassword(scanner.nextLine());

				admin.registerAdmin(admin.getName(), admin.getUsername(), admin.getPassword());
				scanner.close();
				break;
			
		}
			scanner.close();
		} 
	    
	}	

}
