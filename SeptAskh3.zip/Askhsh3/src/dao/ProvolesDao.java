package dao;

import java.sql.*;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import askhsh1.Provoles;

public class ProvolesDao {
	
	public static int save(Provoles p){
		
		int status = 0;
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into provoles(movies_idmovies,provoles_start_date, provoles_end_date,cinemas_idcinemas,contentadmin_idcontentadmin) values(?,?,?,?,?)");
			ps.setString(1,p.getProvoliFilm());
			ps.setString(2,p.getProvoliStartDate());
			ps.setString(3,p.getProvoliEndDate());
			ps.setString(4,p.getProvoliCinema());
			ps.setString(5,p.getProvoliID());
			status = ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	
}

