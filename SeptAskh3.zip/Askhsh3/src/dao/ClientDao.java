package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import askhsh1.Provoles;


public class ClientDao {
	
	public static boolean validate(String username, String hashed, String salt){
		
		boolean status = false;
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from clients where clients_name =? and clients_hashed_pass=? and clients_salt=?");
			ps.setString(1,username);
			ps.setString(2,hashed);
			ps.setString(3,salt);
			ResultSet rs = ps.executeQuery();
			status=rs.next();
			con.close();
			
		}catch(Exception ex){System.out.println(ex);}
		return status;
	
}
	public static List<Provoles> getFilmsByDate(String provoles_start_date, String provoles_end_date){
	
	
		List<Provoles> list = new ArrayList<Provoles>();
	
		try{
		
			InitialContext ctx = new InitialContext();
		
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
		
			Connection con = datasource.getConnection();
		
			PreparedStatement ps = con.prepareStatement("select * from provoles where provoles_start_date=? and provoles_end_date=?");
		
			ps.setString(1,provoles_start_date);
		
			ps.setString(2,provoles_end_date);
		
			ResultSet rs = ps.executeQuery();
		
			
			while(rs.next()){
			
				Provoles p = new Provoles();
			
				p.setProvoliID(rs.getString(1));
			
				p.setProvoliStartDate(rs.getString(2));
			
				p.setProvoliEndDate(rs.getString(3));
			
				p.setProvoliCinema(rs.getString(4));
			
				list.add(p);
		
			
			}
		
			con.close();
	
		}catch(Exception e){System.out.println(e);}
	
		return list;

	}

public static List<Provoles> getAvailableFilms(String provoles_movies_idmovies){
	
	List<Provoles> list = new ArrayList<Provoles>();
	try{
		InitialContext ctx = new InitialContext();
		DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
		Connection con = datasource.getConnection();
		PreparedStatement ps = con.prepareStatement("select * from reservations where provoles_movies_idmovies=? and movie_is_available='true'");
		ps.setString(1,provoles_movies_idmovies);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			Provoles p = new Provoles();
			p.setProvoliID(rs.getString(1));
			p.setProvoliIsAvailable(rs.getBoolean(4));
			list.add(p);
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return list;
}

public static List<Provoles> getReservation(String clients_idclients){
	
	List<Provoles> list = new ArrayList<Provoles>();
	try{
		InitialContext ctx = new InitialContext();
		DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
		Connection con = datasource.getConnection();
		PreparedStatement ps = con.prepareStatement("select * from reservations where clients_idclients=? ");
		ps.setString(1,clients_idclients);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			Provoles p = new Provoles();
			p.setProvoliID(rs.getString(1));
			p.setProvoliCinema(rs.getString(2));
			list.add(p);
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return list;
}

}

