package dao;

import java.sql.*;
import java.util.*;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import askhsh1.Films;

public class FilmDao {

	public static int save(Films f){
		
		int status = 0;
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into movie(filmId,filmTitle,filmCategory,filmDescription) values(?,?,?,?)");
			ps.setString(1,f.getFilmId());
			ps.setString(2,f.getFilmTitle());
			ps.setString(3,f.getFilmCategory());
			ps.setString(4,f.getFilmDescription());
			status = ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static List<Films> getAllRecords(){
		
		List<Films> list = new ArrayList<Films>();
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from movie");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Films f = new Films();
				f.setFilmId(rs.getString(1));
				f.setFilmTitle(rs.getString(2));
				f.setFilmCategory(rs.getString(3));
				f.setFilmDescription(rs.getString(4));
				list.add(f);
			}
			con.close();
		}catch(Exception e){System.out.println(e);}
		return list;
	}
	
	public static int delete(String filmid){
		
		int status = 0;
		int status1 = 0;
		int status2 = 0;

		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps2 = con.prepareStatement("delete from reservations where provoles_movies_idmovies=?");
			PreparedStatement ps1 = con.prepareStatement("delete from provoles where movies_idmovies=?");
			PreparedStatement ps = con.prepareStatement("delete from movie where filmid=?");
			ps2.setString(1,filmid);
			ps1.setString(1,filmid);
			ps.setString(1,filmid);
			status2 = ps2.executeUpdate();
			status1 = ps1.executeUpdate();
			status = ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	
	
}
