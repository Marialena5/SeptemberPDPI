package askhsh1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Admins extends Users{

	public Admins (String name, String username, String password) {
		super(name, username, password);
	}
	
	File usersFile = new File("users.txt");  // Our File with users 
	File adminsFile = new File("admins.txt"); // Our File with admins  
	File tempFile = new File("myTempFile.txt"); // Temp file

	/**
	 * This method reads the file "users.txt" , parses its content in the list lines 
	 * and prints the content of the list
	 * @throws IOException
	 */
	public void viewAllUsers() throws IOException {
		
		List<String> lines = Files.readAllLines(Paths.get("users.txt"), StandardCharsets.UTF_8);

		if(lines.isEmpty()) { // in case the file is empty, the list will be empty too
				System.out.println("No users exist in our database yet!");	
		}else {
			for(int i=0;i<lines.size();i++){
			    System.out.println(lines.get(i));
			} 
		}
	}
	
	/**
	 * This method reads the file "users.txt" to look for the inserted username. 
	 * If found, it prints out that the username already exists and in any other case 
	 * it writes the inserted name, username and password in a new line at the end of 
	 * our file.
	 * @param name
	 * @param username
	 * @param password
	 */
	public void createUser(String name, String username, String password) {
	    
		try { 
	    	boolean user = true;
		    try {
		    	
	        Scanner myReader = new Scanner(usersFile); 
	        
	        while (myReader.hasNextLine()) {
		          String data = myReader.nextLine();
		          String[] arrOfStr = data.split(","); 
		          
		          String user_name = arrOfStr[1];
		          
	        	  if (user_name.equals(username)) {
	        		  user = false;
	        		  System.out.println("Username already exist in our database!");
	        		  break;
	        	  }
	        }
	        myReader.close();
		    } catch (Exception ex) { // TODO apply the right exception
		    	
		    }
	  	    if (user == true) {
		    
	        FileWriter myWriter = new FileWriter("users.txt", true);
	       
	        myWriter.append(name + "," + username + "," + password + "\r\n");
	        myWriter.close();
	        System.out.println("Successfully wrote to the file.");
	        System.out.println("Name: " + name);
	        System.out.println("Username: " + getUsername());
        	System.out.println("Password: " + getPassword());
	  	        }
	      } catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      } 
	}
	
	/**
	 * This method reads the file "users.txt" in search of the inserted username and writes the content of each line in the file "myTempFile.txt".
	 * When the line including it is found, its content will be replaced by the inserted data.
	 * In the end, "users.txt" will be deleted and the temporary file will be renamed to "users.txt"
	 * @param name
	 * @param username
	 * @param password
	 * @throws IOException
	 */
	public void updateUser(String name, String username, String password) throws IOException{

		boolean user = false;
		
		try {
			
		BufferedReader reader = new BufferedReader(new FileReader(usersFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String currentLine;
		
		while ((currentLine = reader.readLine()) != null) {
		      String[] arrOfStr = currentLine.split(","); 
		      
		      String user_name = arrOfStr[1];
		      
			  if (user_name.equals(username)) {
				  user = true;
				  currentLine = currentLine.replaceAll(currentLine, name + "," + username + "," + password);
				  System.out.println("Update OK");
			  }
			  writer.write(currentLine + "\r\n");
	  
		}
			if(user == false) {
					System.out.println("Wrong username!");
				}
		
		reader.close();
		writer.close();	
		usersFile.delete();
		tempFile.renameTo(usersFile);
		
		} catch (Exception ex) { // TODO apply the right exception
			
		} 
		
	}
	
	/**
	 * This method reads the file "users.txt" in order to find the line that includes the inserted username
	 * and at the same time writes the content of this line in the temporary file "myTempFile.txt".
	 * When the line including the username is found, its content will not be written at the temporary file.
	 * In the end, "users.txt" will be deleted and the temporary file will be renamed to "users.txt"
	 * @param username
	 * @throws IOException
	 */
	public void deleteUser(String username) throws IOException {
		
		boolean user = false;
		
		try {
			
		BufferedReader reader = new BufferedReader(new FileReader(usersFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String currentLine;
		
		while ((currentLine = reader.readLine()) != null) {
		      String[] arrOfStr = currentLine.split(","); 
		      
		      String user_name = arrOfStr[1];
		      
			  if (user_name.equals(username)) {
				  user = true;
				  System.out.println("Delete OK");
				  continue;
				  
			  }
			  writer.write(currentLine + "\r\n");
	  
		}
			if(user == false) {
					
				System.out.println("Wrong username!");		
			}
		
		reader.close();
		writer.close();	
		usersFile.delete();
		tempFile.renameTo(usersFile);
		
		} catch (Exception ex) { // TODO apply the right exception
			
		} 
	}
	
	/**
	 * This method reads the file "users.txt" and if the inserted username matches the username of a line 
	 * a confirm message is printed out else a negative one is printed
	 * @param username
	 */
	public void searchUser(String username) {
		
		boolean user = false;
		
		try {
			
		BufferedReader reader = new BufferedReader(new FileReader(usersFile));
		String currentLine;
		
		while ((currentLine = reader.readLine()) != null) {
		      String[] arrOfStr = currentLine.split(","); 
		      
		      String user_name = arrOfStr[1];
		      
			  if (user_name.equals(username)) {
				  user = true;
				  System.out.println("We found you!");
				  System.out.println(currentLine);
			  }
	  
		}
			if(user == false) {
					
				System.out.println("User not found!");	
			}
		
		reader.close();
		
		} catch (Exception ex) { // TODO apply the right exception
		
		}
	}
	
	/**
	 * This method reads the file "users.txt" to look for the inserted username. 
	 * If found, it prints out that the username already exists and in any other case 
	 * it writes the inserted name, username and password in a new line at the end of 
	 * our file.
	 * @param name
	 * @param username
	 * @param password
	 */
	public void registerAdmin(String name, String username, String password) {
	    
		try { 
	    	boolean user = true;
		    
		    try {
		    
		    Scanner myReader = new Scanner(usersFile); 
	        
	        while (myReader.hasNextLine()) {
		          String data = myReader.nextLine();
		          String[] arrOfStr = data.split(","); 
		          
		          String user_name = arrOfStr[1];
		          
	        	  if (user_name.equals(username)) {
	        		  user = false;
	        		  System.out.println("Username already exist in our database!");
	        		      break;
	        	  }
	        }
	        myReader.close();
		    } catch (Exception ex) { // TODO apply the right exception
		    	
		    }
		    
	  	    if (user == true) {
		    
	        FileWriter myWriter = new FileWriter(usersFile, true);
	       
	        myWriter.append(name + "," + username + "," + password + "\r\n");
	        myWriter.close();
	        System.out.println("Successfully wrote to the file.");
	        System.out.println("Name: " + name);
	        System.out.println("Username: " + getUsername());
        	System.out.println("Password: " + getPassword());
	  	        }
	  	    
	      } catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      } 
	}
	
}

