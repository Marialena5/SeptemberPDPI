package mainpackage;

import java.io.IOException;
import java.security.ProviderException;
import java.security.SecureRandom;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.ClientDao;
import dao.ContentAdminDao;
import dao.UserDao;

@WebServlet("/ContentAdminLogin")
public class ContentAdminLogin extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
//		boolean status = ContentAdminDao.validate(username, password);
//		boolean status1 = UserDao.validate(username, password);
//		boolean status2 = ClientDao.validate(username, password);
		
		try {
			SecureRandom random = new SecureRandom(); 
			byte bytes[] = password.getBytes();
		    random.nextBytes(bytes);
		    
		    String hashed = SaltedHashed.getHashMD5(password);
			String salt = SaltedHashed.getHashMD5(password ,random.toString());
			
			boolean status = ContentAdminDao.validate(username, hashed, salt);
			boolean status1 = UserDao.validate(username, hashed, salt);
			boolean status2 = ClientDao.validate(username, hashed, salt);
			
			if(status){
				HttpSession session = request.getSession();  
		        session.setAttribute("username",username);  
				response.sendRedirect("choose.jsp");

			}
			else if(status1) {
				HttpSession session = request.getSession();  
		        session.setAttribute("username",username);  
				response.sendRedirect("adminChoose.jsp");  
				
			}
			else if(status2) {
				HttpSession session = request.getSession();  
		        session.setAttribute("username",username);  
				response.sendRedirect("clientChoose.jsp");
			}
			else{
			
				request.getRequestDispatcher("error.jsp").include(request, response);
			}
			
			}catch (ProviderException e) { 

		        System.out.println("Exception thrown : " + e); 
		    } 
		
		
//		if(status){
//			HttpSession session = request.getSession();  
//	        session.setAttribute("username",username);  
//			response.sendRedirect("choose.jsp");
//
//		}
//		else if(status1) {
//			HttpSession session = request.getSession();  
//	        session.setAttribute("username",username);  
//			response.sendRedirect("adminChoose.jsp");  
//			
//		}
//		else if(status2) {
//			HttpSession session = request.getSession();  
//	        session.setAttribute("username",username);  
//			response.sendRedirect("clientChoose.jsp");
//		}
//		else{
//		
//			request.getRequestDispatcher("error.jsp").include(request, response);
//		}

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

}
