package mainpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import askhsh1.Provoles;
import dao.ClientDao;

/**
 * Servlet implementation class ClientsReservations
 */
@WebServlet("/ClientsReservations")
public class ClientsReservations extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String clients_idclients = request.getParameter("clients_idclients");		

		request.getRequestDispatcher("availableFilms.jsp").include(request, response);
		
		out.println("<h1>Films Programm by "+clients_idclients.toUpperCase()+"</h1>");
		List<Provoles> list = ClientDao.getReservation(clients_idclients);
		
		out.print("<table style=\"color:white;\" >");
		out.println("<tr><th>Id Films</th><th>Cinema ID</th></tr>");
		
		for(Provoles b:list){
			out.println("<tr><td>"+b.getProvoliID()+"</td><td>"+b.getProvoliCinema() + "</td></tr>");

		}
		out.println("</table>");
		out.close();
	}
       
   
}
