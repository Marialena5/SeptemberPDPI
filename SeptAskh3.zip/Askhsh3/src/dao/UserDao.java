package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import askhsh1.Users;

public class UserDao {

	public static boolean validate(String username, String hashed, String salt){
		
		boolean status = false;
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where admin_name =? and idadmin_hashed_pass=? and idadmin_salt=?");
			ps.setString(1,username);
			ps.setString(2,hashed);
			ps.setString(3,salt);
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}
	
	public static int save(Users u){
		
		int status = 0;
		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into contentadmin(idcontentadmin, contentadmin_name, contentadmin_surname, admin_idadmin, idca_hashed_pass, idca_salt) values(?,?,?,?,?,?)");
			ps.setString(1,u.getIdCa());
			ps.setString(2,u.getName());
			ps.setString(3,u.getUsername());
			ps.setString(4,u.getPassword());
			ps.setString(5,u.getIdCaHash());
			ps.setString(6,u.getIdCaSalt());

			status = ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static int delete(String idcontentadmin){
		
		int status = 0;
		int status1 = 0;

		try{
			InitialContext ctx = new InitialContext();
			DataSource datasource = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");
			Connection con = datasource.getConnection();
			PreparedStatement ps1 = con.prepareStatement("delete from provoles where contentadmin_idcontentadmin=?");
			PreparedStatement ps = con.prepareStatement("delete from contentadmin where idcontentadmin=?");
			ps1.setString(1,idcontentadmin);
			ps.setString(1,idcontentadmin);
			status1 = ps1.executeUpdate();
			status = ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	

}
