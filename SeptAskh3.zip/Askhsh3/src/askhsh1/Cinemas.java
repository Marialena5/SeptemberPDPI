package askhsh1;

public class Cinemas extends Users{
	private String cinemaId;
	private boolean cinemaIs3D;
	private int cinemaNumberOfSeats;
	
	public Cinemas(String name, String username, String password) 
	{
		super(name, username, password);
	}
	
	public void setcinemaId(String cinemaId) 
	{
		this.cinemaId = cinemaId;
	}
	public void setcinemaIs3D(boolean cinemaIs3D) 
	{
		this.cinemaIs3D = cinemaIs3D;
	}
	public void setcinemaNumberOfSeats(int cinemaNumberOfSeats) 
	{
		this.cinemaNumberOfSeats = cinemaNumberOfSeats;
	}
	
	public String getcinemaId() 
	{
		return cinemaId;
	}
	public boolean getcinemaIs3D() 
	{
		return cinemaIs3D;
	}
	public int getcinemaNumberOfSeats() 
	{
		return cinemaNumberOfSeats;
	}
	

}
