package mainpackage;

import askhsh1.Films;
import dao.FilmDao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ContentAdminServlet")
public class ContentAdminServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		request.getRequestDispatcher("insert.jsp").include(request, response);
		
		String filmId = request.getParameter("filmId");
		String filmTitle = request.getParameter("filmTitle");
		String filmCategory = request.getParameter("filmCategory");
		String filmDescription = request.getParameter("filmDescription");
			
		Films f = new Films();
		f.setFilmId(filmId);
		f.setFilmTitle(filmTitle);
		f.setFilmCategory(filmCategory);
		f.setFilmDescription(filmDescription);
		
		if(filmId == "" || filmTitle == "" || filmCategory == "" || filmDescription == "") {
			
			out.print("<h3 style= \"color:white;\">Unable to add film!</h3>");
			
		}else {
			
			int status = FilmDao.save(f);
			
			if(status>0){
				
				out.print("<h3 style= \"color:white;\">Film added successfully</h3>");
				
			}else{
				out.print("<h3 style= \"color:white;\">Unable to add film!</h3>");
			}		
			
		}
		
		
		out.close();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		
		request.getRequestDispatcher("deletef.jsp").include(request, response);
		
		String filmid = request.getParameter("filmid");
		int status = FilmDao.delete(filmid);
		String movies_idmovies = request.getParameter("filmid");
		int status1 = FilmDao.delete(movies_idmovies);
		String provoles_movies_idmovies = request.getParameter("filmid");
		int status2 = FilmDao.delete(provoles_movies_idmovies);
	

		if(status>0 || status1>0 || status2>0){
			
			out.print("<h3 style= \"color:white;\">Film deleted successfully</h3>");
			
		}else{
			out.print("<h3 style= \"color:white;\">Unable to delete film!</h3>");
		}
		out.print(status + " " + status1);
				
		out.close();
		
	}



}
