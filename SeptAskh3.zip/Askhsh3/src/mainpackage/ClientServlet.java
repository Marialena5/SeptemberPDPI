package mainpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import askhsh1.Provoles;
import dao.ClientDao;
/**
 * Servlet implementation class ClientServlet
 */
@WebServlet("/ClientServlet")
public class ClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String provoles_start_date = request.getParameter("provoles_start_date");
			String provoles_end_date = request.getParameter("provoles_end_date");
			

			request.getRequestDispatcher("availableFilms.jsp").include(request, response);
			
			out.println("<h1>Films Program by "+provoles_start_date.toUpperCase()+"</h1>");
			List<Provoles> list = ClientDao.getFilmsByDate(provoles_start_date, provoles_end_date);
			
			out.print("<table style=\"color:white;\" >");
			out.println("<tr><th>Id Films</th><th>Films start date</th><th>Films end date</th><br>");
			
			for(Provoles b:list){
				out.println("<tr><td>"+b.getProvoliID()+"</td><td>"+b.getProvoliStartDate()+"</td><td>"+b.getProvoliEndDate()+"</td></tr>");
			}
			out.println("</table>");
			out.close();
		}


}
