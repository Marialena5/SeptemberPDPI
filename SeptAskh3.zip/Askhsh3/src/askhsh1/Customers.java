package askhsh1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Customers extends Users{

	public Customers(String name, String username, String password) {
		super(name, username, password);
	}
	
	public Customers(String username) {
		super(username); 
	}
	
	File customersFile = new File("customers.txt"); // Our File with customers 
	File provolesFile = new File("provoles.txt"); // Our File with provoles
	File cinemasFile = new File("cinemas.txt"); // Our File with cinemas
	File tempFile = new File("myTempFile.txt"); // Temp file

	/**
	 * This method reads the file "provoles.txt" and prints the available films and their info
	 */
	public void showAvailableFilms() 
	{
		try {

		Scanner myReader = new Scanner(provolesFile); 
        
        Provoles provoli = new Provoles();
        
        while (myReader.hasNextLine()) {
          String data = myReader.nextLine();
          String[] arrOfStr = data.split(","); 
          
          provoli.setProvoliID(arrOfStr[0]);
          provoli.setProvoliFilm(arrOfStr[1]);
          provoli.setProvoliCinema(arrOfStr[2]);
          provoli.setProvoliStartDate(arrOfStr[3]);
          provoli.setProvoliEndDate(arrOfStr[4]);
          provoli.setProvoliNumberOfReservations(Integer.parseInt(arrOfStr[5]));
          provoli.setProvoliIsAvailable(Boolean.parseBoolean(arrOfStr[6]));
          
          if(data.contains("Available")) {
        	  System.out.print("Code:" + provoli.getProvoliID() +" ");
        	  System.out.print("Title:" + provoli.getProvoliFilm() + " ");
        	  System.out.print("Room:" + provoli.getProvoliCinema() + " ");
        	  System.out.print("Start date:" + provoli.getProvoliStartDate() + " ");
        	  System.out.print("End date:" + provoli.getProvoliEndDate() + " ");
        	  System.out.print("Total reservations:" + provoli.getProvoliNumberOfReservations() + " ");
        	  System.out.println(provoli.isProvoliIsAvailable());
          }
    }   
        myReader.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
	}

	/**
	 *This method writes a new line at the file "customers.txt" if the film is available and the title exist
	 * @param username
	 * @param inpFilmTitle
	 * @param inpSeats
	 */
	public void makeReservation(String username, String inpFilmTitle, int inpSeats)
	{
		int remainingseats = 0;
		boolean reserve = false;
		try {

        Scanner myReader = new Scanner(provolesFile); 
        
        while (myReader.hasNextLine()) {
          String data = myReader.nextLine();
          String[] arrOfStr = data.split(","); 
          
          String title = arrOfStr[1];
          String cinema = arrOfStr[2];
          String available = arrOfStr[6];
          
    	  if (title.equals(inpFilmTitle)) {
    		  reserve = true;
    		  System.out.println(title);
    		  if (available.equals("Available")) {
    			  
		        Scanner myReader2 = new Scanner(cinemasFile);
		        while (myReader2.hasNextLine()) {
			          String data2 = myReader2.nextLine();
			          String[] arrOfStr2 = data2.split(","); 
			          String idcinema = arrOfStr2[0];
			          String is3D = arrOfStr2[1];
			          int seats = Integer.parseInt(arrOfStr2[2]);
			          
			          if(idcinema.equals(cinema)) {
			        	   if(inpSeats <= seats) {
			        		   try {
			        			    remainingseats = seats - inpSeats;
									FileWriter myWriter = new FileWriter(customersFile, true);
		        			        myWriter.append(username + "," + title + "," + cinema + "," + inpSeats + "\r\n");
		        			        myWriter.close();
								}catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
  
			       			try {
			       				
			       			BufferedReader reader = new BufferedReader(new FileReader(cinemasFile));
			       			BufferedWriter writer = null;
			       			writer = new BufferedWriter(new FileWriter(tempFile));

			       			String currentLine;
	
			       			try {
								while((currentLine = reader.readLine()) != null) {
									String[] arrOfStr3 = currentLine.split(","); 
			  		      
									String iDcinema = arrOfStr3[0];
			       			
								    if(iDcinema.equals(cinema)) {
								    	currentLine = currentLine.replaceAll(currentLine, cinema + "," + is3D + "," + remainingseats);
								    }

								    writer.write(currentLine + "\r\n");
								}
							} catch (IOException e) {
								// TODO Auto-generated catch block
								System.out.println("An error occurred.");
								e.printStackTrace();
							}
			       	       
			       				
			       				myReader2.close(); 
								writer.close();
								reader.close();
							
							cinemasFile.delete();
			       			tempFile.renameTo(cinemasFile);

			       			} catch (IOException e1) {
								// TODO Auto-generated catch block
			       				System.out.println("An error occurred.");
								e1.printStackTrace();
							}
			 	        	  break;
			 	          } 
			          } 
		        }
		        
		  } 
		  
	  }
}
        if(reserve == false) {
        	System.out.println("Wrong Input.");
        }
        myReader.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
		

	}

	/**
	 * This method reads the file "customers.txt" and prints the data of every line that includes the inserted username 
	 * @param username
	 */
	
	public void viewReservation(String username) 
	{
		boolean reservation = false;
		
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader(customersFile));
			String currentLine;
			
			while ((currentLine = reader.readLine()) != null) {
			      String[] arrOfStr = currentLine.split(","); 
			      
			      String user_name = arrOfStr[0];
			      String title = arrOfStr[1];
		          String room = arrOfStr[2];
		          String seats = arrOfStr[3];
			      
				  if (user_name.equals(username)) {
					  reservation = true;
					  System.out.print("Title:" + title + " ");
		        	  System.out.print("Room:" + room + " ");
		        	  System.out.println("Seats:" + seats + " ");
					  continue;
					  
				  }
		  
			}
				if(reservation == false) { // in case the inserted username does not exist in the file
						
					System.out.println("Wrong username!");		
				}
			
			reader.close();

		}catch (Exception ex) { // TODO apply the right exception
			
		} 
		}
		

}